RYO'S IPHONE — Wallpaper Update

Wallpaper: your uploaded black-and-white 666 graffiti photo.
Gallery: your ten previously uploaded images.

Open index.html in a browser to preview.
To publish on GitHub Pages, upload index.html and the ENTIRE photos folder to your repository root. Settings > Pages > Deploy from branch > main / (root).
